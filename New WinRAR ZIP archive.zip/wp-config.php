<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'manger');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '8842245');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'w<@lz{Q72l1#f@C>{VM2egg N$(hY=68cq;j$??U^mRWz Lm]9NWWpKwy~jNi#d#');
define('SECURE_AUTH_KEY',  'GduB7(^$m@5*# ^fy G?$Euc2iMN7iW2i:I2FF?qMR @z=<oRu]x8? KL10|}^~F');
define('LOGGED_IN_KEY',    'mTJ,5^l9$l-E!jGs1cyHKz=}!gKg@x3grS$@Mv9_{MWR|h*$i{T>B0E=~h.|Sx$(');
define('NONCE_KEY',        'w82L6*FV;Ozd?a(Si7!k/)VtHKl<k|5(EFtVt C-jrEw-;P{lk[a9?v^^:tz~Li]');
define('AUTH_SALT',        't4e7/Oi-,k;g xz0^*<-xZdT%Dt>`mOugaX I=bj<9muG*l9o43p<,uoCd+CGdJI');
define('SECURE_AUTH_SALT', '/+* KoxQ!0we]_bGGi;O/?Y*[$,VHZlr5]bc`5N4Lf>{v{O2vSf2XzR&X`8%- _m');
define('LOGGED_IN_SALT',   '$EInvz(.Lm=]=#D/b,O7lsY:|PWn.]~|jXG`7i%uk5ywW0O<vxH`=+=|eX 323n]');
define('NONCE_SALT',       '*8!JxWCHOm$XEc;EU7_x[OPo/LLjovAeW{_@valhb[Zu7M5kLzj{#n]Yb^Sj/87B');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
